from databricks.labs.remorph.rct.transpiler.server.py import server

if __name__ == "__main__":
    server.start_io()
