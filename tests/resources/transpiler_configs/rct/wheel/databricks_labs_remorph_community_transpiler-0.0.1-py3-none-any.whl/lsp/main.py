from databricks.labs.remorph.rct.transpiler.server import server

if __name__ == "__main__":
    server.start_io()
